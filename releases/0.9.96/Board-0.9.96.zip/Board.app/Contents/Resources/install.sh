#!/bin/bash
# Script d installation pour Board
echo "Installation de Board..."
INSTALL_DIR="$HOME/Library/Application Support/Board"
mkdir -p "$INSTALL_DIR"
echo "Installation terminée avec succès!"
exit 0
