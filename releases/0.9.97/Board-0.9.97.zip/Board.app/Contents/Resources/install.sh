#!/bin/bash

# Variables d'installation
APP_NAME="Board"
INSTALL_DIR="/Applications"
SUPPORT_DIR="$HOME/Library/Application Support/$APP_NAME"
SOURCE_APP="$1"

# Fonction de log
log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1"
}

# Vérification des arguments
if [ -z "$SOURCE_APP" ]; then
    log "Error: Source application path not provided"
    exit 1
fi

# Arrêt de l'application si elle est en cours d'exécution
pkill -x "$APP_NAME"
sleep 1

# Création des dossiers nécessaires
log "Creating required directories..."
mkdir -p "$SUPPORT_DIR"

# Suppression de l'ancienne version
if [ -d "$INSTALL_DIR/$APP_NAME.app" ]; then
    log "Removing previous version..."
    rm -rf "$INSTALL_DIR/$APP_NAME.app"
fi

# Installation de la nouvelle version
log "Installing new version..."
cp -R "$SOURCE_APP" "$INSTALL_DIR/"

# Définition des permissions
log "Setting permissions..."
chmod -R 755 "$INSTALL_DIR/$APP_NAME.app"

log "Installation completed successfully!"
exit 0
