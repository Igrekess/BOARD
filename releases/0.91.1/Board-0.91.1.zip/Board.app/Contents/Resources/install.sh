#!/bin/bash

# Variables d'installation
APP_NAME="Board"
INSTALL_DIR="/Applications"
SUPPORT_DIR="$HOME/Library/Application Support/$APP_NAME"
BACKUP_DIR="$SUPPORT_DIR/backups"
SOURCE_APP="$1"

# Fonction de log
log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1"
}

# Vérification des arguments
if [ -z "$SOURCE_APP" ]; then
    log "Error: Source application path not provided"
    exit 1
fi

# Vérifier que l'application source existe
if [ ! -d "$SOURCE_APP" ]; then
    log "Error: Source application not found at $SOURCE_APP"
    exit 1
fi

# Log du chemin source
log "Source application path: $SOURCE_APP"

# Création des dossiers nécessaires
log "Creating required directories..."
mkdir -p "$SUPPORT_DIR" "$BACKUP_DIR"

# Sauvegarder l'ancienne version
if [ -d "$INSTALL_DIR/$APP_NAME.app" ]; then
    log "Backing up previous version..."
    BACKUP_NAME="$APP_NAME-$(date +%Y%m%d-%H%M%S).app"
    cp -R "$INSTALL_DIR/$APP_NAME.app" "$BACKUP_DIR/$BACKUP_NAME"
    if [ $? -ne 0 ]; then
        log "Error: Failed to backup current version"
        exit 1
    fi
fi

# Arrêt de l'application si elle est en cours d'exécution
log "Stopping current application..."
pkill -x "$APP_NAME"
sleep 2

# Vérifier si l'application est toujours en cours d'exécution
if pgrep -x "$APP_NAME" > /dev/null; then
    log "Application still running, forcing quit..."
    pkill -9 -x "$APP_NAME"
    sleep 1
fi

# Suppression de l'ancienne version
log "Removing previous version..."
rm -rf "$INSTALL_DIR/$APP_NAME.app"

# Installation de la nouvelle version
log "Installing new version..."
log "Copying from: $SOURCE_APP"
log "Copying to: $INSTALL_DIR/$APP_NAME.app"

# Vérifier si le dossier de destination est accessible
if [ ! -w "$INSTALL_DIR" ]; then
    log "Error: No write permission in $INSTALL_DIR"
    exit 1
fi

# Copier l'application
cp -R "$SOURCE_APP" "$INSTALL_DIR/$APP_NAME.app"
if [ $? -ne 0 ]; then
    log "Error: Failed to copy application"
    exit 1
fi

# Vérifier que l'installation a réussi
if [ ! -d "$INSTALL_DIR/$APP_NAME.app" ]; then
    log "Error: Installation verification failed"
    exit 1
fi

# Définition des permissions
log "Setting permissions..."
chmod -R 755 "$INSTALL_DIR/$APP_NAME.app"
chown -R root:wheel "$INSTALL_DIR/$APP_NAME.app"

# Vérifier que l'application est exécutable
if [ ! -x "$INSTALL_DIR/$APP_NAME.app/Contents/MacOS/$APP_NAME" ]; then
    log "Error: Application is not executable"
    exit 1
fi

# Vérifier que l'application est signée
if ! codesign -v "$INSTALL_DIR/$APP_NAME.app" 2>/dev/null; then
    log "Warning: Application is not signed"
fi

# Vérifier la version installée
if [ -f "$INSTALL_DIR/$APP_NAME.app/Contents/Info.plist" ]; then
    VERSION=$(/usr/libexec/PlistBuddy -c "Print :CFBundleShortVersionString" "$INSTALL_DIR/$APP_NAME.app/Contents/Info.plist")
    log "Installed version: $VERSION"
fi

# Attendre un peu plus longtemps pour s'assurer que tout est bien fermé
sleep 2

# Nettoyage des dossiers temporaires
log "Cleaning up temporary folders..."
if [ -d "$(dirname "$SOURCE_APP")/install" ]; then
    rm -rf "$(dirname "$SOURCE_APP")/install"
    log "Removed install folder"
fi

if [ -d "$(dirname "$SOURCE_APP")/backup" ]; then
    rm -rf "$(dirname "$SOURCE_APP")/backup"
    log "Removed backup folder"
fi

log "Installation completed successfully!"
exit 0
